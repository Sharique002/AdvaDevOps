# INT333 — DevOps Advance Configuration Management

Syllabus-aligned study notes for **Session 2026–27**.

This repository organizes the course into six chapter-wise Markdown files and a practical-experiments guide. The unit structure and listed topics follow the uploaded INT333 syllabus. Explanations, examples and suggested lab steps expand those headings for study; they are not additional official syllabus requirements.

## Course outcomes

| Outcome | Expected competency |
|---|---|
| CO1 | Understand the basics of Puppet |
| CO2 | Demonstrate configuration management skills using Puppet |
| CO3 | Install and configure Nagios for continuous monitoring |
| CO4 | Understand and implement infrastructure automation using Terraform |
| CO5 | Describe the fundamentals of Ansible and its installation process |
| CO6 | Construct Ansible playbooks to automate multiple system administration tasks |

## Chapter-wise notes

| Unit | Chapter | Notes |
|---|---|---|
| I | Puppet Basics | [01-puppet-basics.md](chapters/01-puppet-basics.md) |
| II | Advanced Puppet | [02-advanced-puppet.md](chapters/02-advanced-puppet.md) |
| III | Nagios Monitoring | [03-nagios-monitoring.md](chapters/03-nagios-monitoring.md) |
| IV | Infrastructure as Code with Terraform | [04-terraform-iac.md](chapters/04-terraform-iac.md) |
| V | Introduction to Ansible | [05-introduction-to-ansible.md](chapters/05-introduction-to-ansible.md) |
| VI | Advanced Ansible | [06-advanced-ansible.md](chapters/06-advanced-ansible.md) |

## Practical experiments

[Practical Experiments 1–15](practicals/experiments.md) — aims, concepts, procedure, verification and evidence suggestions for every experiment listed in the syllabus.

## Suggested study approach

1. Read the unit notes and learn the terms.
2. Recreate diagrams and workflows without looking at the notes.
3. Practise commands in a disposable VM, container or approved lab.
4. Complete the related practical and capture genuine output.
5. Answer the revision questions at the end of each chapter.

## Safety and environment notes

- Commands are illustrative and may need adjustment for the Linux distribution, package version, privileges and lab topology.
- Review any command that installs packages, changes services, modifies infrastructure or deletes resources before running it.
- Terraform examples require a compatible provider and working API access; do not apply a plan until its effects are understood.
- AWS/Azure/GCP practicals can incur charges. Use instructor-approved accounts, least-privilege credentials and a cleanup plan.
- Never commit credentials, private keys, `.env` secrets or Terraform state files.

## Syllabus references

The structure follows the supplied **INT333: DevOps Advance Configuration Management**, Session 2026–27 syllabus. The syllabus lists these references:

1. *Mastering Puppet 5* — Ryan Russell-Yates, Packt Publishing.
2. *Ansible for DevOps: Server and Configuration Management for Humans* — Jeff Geerling.
3. *Learning Nagios* — Wojciech Kocjan.

These notes are a learning companion, not a replacement for prescribed textbooks, official product documentation, lab instructions or instructor guidance.
